﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using WixWPF;
using $globalsafeprojectname$UI;

[assembly: AssemblyTitle("$globalsafeprojectname$UI")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("$globalregisteredorganization$")]
[assembly: AssemblyProduct("$globalprojectname$UI")]
[assembly: AssemblyCopyright("Copyright © $globalyear$")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("$globalguid4$")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

[assembly: StartupWindow(typeof(MainWindow))]
