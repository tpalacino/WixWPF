﻿using System;
using System.Windows;
using System.Windows.Controls;
using WixWPF;
using Wix = Microsoft.Tools.WindowsInstallerXml.Bootstrapper;

namespace $safeprojectname$
{
	/// <summary>Interaction logic for MainWindow.xaml</summary>
	public partial class MainWindow : BaseBAWindow
	{
		#region Constructors

		/// <summary>Creates a new instance of <see cref="MainWindow" />.</summary>
		public MainWindow()
		{
			InitializeComponent();
		}

		#endregion Constructors
	}
}